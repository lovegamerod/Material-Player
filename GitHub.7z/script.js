/**
 * Material Music Pro - 最终修复版
 */

let playlists = {}, allSongs = [], currentPlaylist = [], currentIndex = 0;
let isPlaying = false, lyricsData = [];

// 滚动锁变量
let isUserScrolling = false;
let scrollUnlockTimer = null;
let currentOffset = 0; 

const audio = document.getElementById('audio-player');
const lyricsContainer = document.getElementById('lyrics-container');
const lyricsTrack = document.getElementById('lyrics-track');
const appBg = document.getElementById('app-bg');

async function init() {
    try {
        const response = await fetch('./data.json');
        playlists = await response.json();
        
        Object.keys(playlists).forEach(pName => {
            playlists[pName].forEach((s, i) => allSongs.push({ ...s, playlistId: pName, songIndex: i }));
        });

        renderNav();
        initDrawer(); // 初始化移动端抽屉
        initSearch();
        initLyricsInteraction();
        initControls();
        await restoreState();
        
        window.addEventListener('hashchange', handleRoute);
    } catch (e) { console.error("Init Error:", e); }
}

// --- 移动端抽屉逻辑 (新增) ---
function initDrawer() {
    const drawer = document.getElementById('mobile-nav-drawer');
    const toggle = document.getElementById('mobile-playlist-toggle');
    const overlay = document.getElementById('drawer-overlay');
    const closeBtn = document.getElementById('close-drawer');

    const open = () => drawer.classList.add('active');
    const close = () => drawer.classList.remove('active');

    if(toggle) toggle.onclick = open;
    if(overlay) overlay.onclick = close;
    if(closeBtn) closeBtn.onclick = close;
}

// --- 状态恢复 ---
async function restoreState() {
    const last = JSON.parse(localStorage.getItem('music_last_state'));
    if (last && playlists[last.playlistId]) {
        window.location.hash = last.playlistId;
        currentPlaylist = playlists[last.playlistId];
        currentIndex = last.index;
        const song = currentPlaylist[currentIndex];
        updatePlayerUI(song);
        audio.src = song.file;
        audio.currentTime = last.time; // 恢复进度但不自动播
        loadLyrics(song.file.replace(/\.(mp3|flac|wav|ogg)$/i, '.lrc'));
    } else { handleRoute(); }
}

function saveState() {
    if (!currentPlaylist[currentIndex]) return;
    localStorage.setItem('music_last_state', JSON.stringify({
        playlistId: decodeURIComponent(window.location.hash.substring(1)),
        index: currentIndex, time: audio.currentTime
    }));
}
setInterval(saveState, 5000);

// --- 核心播放逻辑 ---
function updatePlayerUI(song) {
    // 迷你栏
    document.getElementById('mini-title').innerText = song.title;
    document.getElementById('mini-artist').innerText = song.artist;
    document.getElementById('mini-cover').src = song.cover;
    document.getElementById('mini-cover').classList.remove('hidden');

    // 全屏栏
    document.getElementById('full-title').innerText = song.title;
    document.getElementById('full-artist').innerText = song.artist;
    document.getElementById('full-album').innerText = song.album || "Unknown Album";
    document.getElementById('full-cover').src = song.cover;
    
    // 背景
    appBg.style.backgroundImage = `url('${song.cover}')`;
    appBg.style.opacity = '1';

    audio.onloadedmetadata = () => {
        document.getElementById('time-duration').innerText = formatTime(audio.duration);
    };
}

async function playSong(index) {
    currentIndex = index;
    const song = currentPlaylist[index];
    updatePlayerUI(song);
    audio.src = song.file;
    try {
        await audio.play();
        isPlaying = true;
    } catch (e) { console.warn("Auto-play blocked"); }
    updatePlayState();
    loadLyrics(song.file.replace(/\.(mp3|flac|wav|ogg)$/i, '.lrc'));
}

function togglePlay() {
    audio.paused ? audio.play() : audio.pause();
    isPlaying = !audio.paused;
    updatePlayState();
}

function updatePlayState() {
    const icon = isPlaying ? 'pause' : 'play_arrow';
    const iconFull = isPlaying ? 'pause_circle' : 'play_circle';
    document.querySelector('#btn-play-mini span').innerText = icon;
    document.querySelector('#btn-play-full span').innerText = iconFull;
}

// --- 歌词系统 (核心修复部分) ---
async function loadLyrics(url) {
    lyricsTrack.innerHTML = '<p class="lyric-line" style="text-align:center">Loading...</p>';
    updateLyricsTransform(0);
    try {
        const res = await fetch(url);
        const text = await res.text();
        parseLyrics(text);
    } catch (e) {
        lyricsTrack.innerHTML = '<p class="lyric-line" style="text-align:center">暂无歌词</p>';
        lyricsData = [];
    }
}

function parseLyrics(text) {
    const lines = text.split('\n');
    const tempMap = new Map();
    
    lines.forEach(line => {
        const match = /\[(\d{2}):(\d{2})(\.\d{2,3})?\]/.exec(line);
        if (match) {
            const time = parseInt(match[1]) * 60 + parseInt(match[2]) + (match[3] ? parseFloat(match[3]) : 0);
            const content = line.replace(/\[.*?\]/g, '').trim();
            if (content) {
                if (tempMap.has(time)) {
                    tempMap.set(time, tempMap.get(time) + `<span class="lyric-sub">${content}</span>`);
                } else {
                    tempMap.set(time, content);
                }
            }
        }
    });

    lyricsData = Array.from(tempMap.entries())
        .map(([time, text]) => ({ time, text }))
        .sort((a, b) => a.time - b.time);

    lyricsTrack.innerHTML = lyricsData.map((l, i) => 
        `<div class="lyric-line" id="lrc-${i}" onclick="seekFromLyric(${l.time})">${l.text}</div>`
    ).join('');
}

// 自由滚动处理
function initLyricsInteraction() {
    const handleScroll = (deltaY) => {
        if(lyricsData.length === 0) return;
        isUserScrolling = true;
        document.getElementById('btn-sync-lyrics').style.display = 'flex';
        currentOffset -= deltaY * 0.6; // 阻尼系数
        updateLyricsTransform(currentOffset);
    };

    lyricsContainer.addEventListener('wheel', (e) => handleScroll(e.deltaY), { passive: true });
    
    let touchStartY = 0;
    lyricsContainer.addEventListener('touchstart', (e) => { touchStartY = e.touches[0].clientY; }, { passive: true });
    lyricsContainer.addEventListener('touchmove', (e) => {
        const delta = touchStartY - e.touches[0].clientY;
        touchStartY = e.touches[0].clientY;
        handleScroll(delta);
    }, { passive: true });
}

function updateLyricsTransform(offset) {
    lyricsTrack.style.transform = `translateY(${offset}px)`;
}

function syncLyrics(force = false) {
    // 如果正在被用户拖动且非强制，则不自动滚动
    if ((isUserScrolling && !force) || lyricsData.length === 0) return;

    let activeIndex = -1;
    const ct = audio.currentTime;
    for (let i = 0; i < lyricsData.length; i++) {
        if (ct >= lyricsData[i].time) activeIndex = i;
        else break;
    }

    if (activeIndex !== -1) {
        const lines = lyricsTrack.querySelectorAll('.lyric-line');
        lines.forEach((l, idx) => l.classList.toggle('active', idx === activeIndex));
        
        const activeLine = document.getElementById(`lrc-${activeIndex}`);
        if (activeLine) {
            const containerCenter = lyricsContainer.clientHeight / 2;
            const targetOffset = containerCenter - activeLine.offsetTop - (activeLine.clientHeight / 2);
            
            // 平滑更新当前位移
            currentOffset = targetOffset;
            updateLyricsTransform(currentOffset);
        }
    }
}

// [关键修复] 点击歌词跳转
window.seekFromLyric = function(time) {
    audio.currentTime = time;
    
    // 1. 强制重置滚动锁
    isUserScrolling = false; 
    
    // 2. 隐藏恢复按钮
    document.getElementById('btn-sync-lyrics').style.display = 'none';
    
    // 3. 确保播放
    if (!isPlaying) togglePlay();

    // 4. 立即强制对齐，防止 onScroll 事件干扰
    syncLyrics(true); 
};

// --- 其他 UI 控制 ---
function initControls() {
    // 播放暂停
    const toggleFunc = (e) => { e.stopPropagation(); togglePlay(); };
    document.getElementById('btn-play-mini').onclick = toggleFunc;
    document.getElementById('btn-play-full').onclick = toggleFunc;

    // 切歌
    const prevFunc = (e) => { e.stopPropagation(); playSong((currentIndex - 1 + currentPlaylist.length) % currentPlaylist.length); };
    const nextFunc = (e) => { e.stopPropagation(); playSong((currentIndex + 1) % currentPlaylist.length); };
    
    document.getElementById('btn-prev-mini').onclick = prevFunc;
    document.getElementById('btn-next-mini').onclick = nextFunc;
    document.getElementById('btn-prev-full').onclick = prevFunc;
    document.getElementById('btn-next-full').onclick = nextFunc;

    // 进度条拖动
    document.getElementById('full-progress-wrapper').onclick = (e) => {
        e.stopPropagation();
        const rect = e.currentTarget.getBoundingClientRect();
        audio.currentTime = ((e.clientX - rect.left) / rect.width) * audio.duration;
    };

    // 全屏开关
    document.getElementById('mini-player').onclick = () => document.getElementById('lyrics-overlay').classList.add('open');
    document.getElementById('btn-close-lyrics').onclick = (e) => {
        e.stopPropagation();
        document.getElementById('lyrics-overlay').classList.remove('open');
    };

    // 恢复同步按钮
    document.getElementById('btn-sync-lyrics').onclick = (e) => {
        e.stopPropagation();
        isUserScrolling = false;
        e.currentTarget.style.display = 'none';
        syncLyrics(true);
    };

    audio.addEventListener('timeupdate', () => {
        if (!audio.duration) return;
        const pct = (audio.currentTime / audio.duration) * 100;
        document.getElementById('mini-progress-fill').style.width = pct + '%';
        document.getElementById('full-progress-fill').style.width = pct + '%';
        document.getElementById('time-current').innerText = formatTime(audio.currentTime);
        syncLyrics(); // 自动滚动
    });
    
    audio.addEventListener('ended', nextFunc);
}

// 导航渲染（含抽屉）
function renderNav() {
    const html = Object.keys(playlists).map(key => `
        <div class="nav-item" data-id="${key}" onclick="selectPlaylist('${key}')">
            <span class="material-symbols-rounded">folder</span><span>${key}</span>
        </div>
    `).join('');
    
    document.getElementById('playlist-nav').innerHTML = html;
    document.getElementById('mobile-playlist-nav').innerHTML = html;
}

window.selectPlaylist = (key) => {
    window.location.hash = key;
    document.getElementById('mobile-nav-drawer').classList.remove('active');
    handleRoute();
};

function handleRoute() {
    const hash = decodeURIComponent(window.location.hash.substring(1));
    if (hash && playlists[hash]) {
        currentPlaylist = playlists[hash];
        document.querySelectorAll('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.id === hash));
        document.getElementById('playlist-title').innerText = hash;
        renderSongList(currentPlaylist);
    }
}

function initSearch() {
    const input = document.getElementById('search-input');
    if(!input) return;
    input.oninput = (e) => {
        const q = e.target.value.toLowerCase().trim();
        if (!q) { handleRoute(); return; }
        const f = allSongs.filter(s => s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q));
        renderSongList(f, true);
    };
}

function renderSongList(songs, isSearch = false) {
    document.getElementById('song-list').innerHTML = songs.map((s, i) => `
        <div class="song-item" onclick="event.stopPropagation(); ${isSearch ? `playFromSearch('${s.playlistId}', ${s.songIndex})` : `playSong(${i})`}">
            <img src="${s.cover}" class="song-cover-mini" onerror="this.src='https://via.placeholder.com/150'">
            <div class="song-info"><b>${s.title}</b><small>${s.artist}</small></div>
        </div>
    `).join('');
}

window.playFromSearch = (pid, idx) => {
    window.location.hash = pid;
    currentPlaylist = playlists[pid];
    playSong(idx);
};

function formatTime(s) {
    return `${Math.floor(s / 60)}:${Math.floor(s % 60).toString().padStart(2, '0')}`;
}

// 1. 在顶部变量声明处添加
let playMode = 'sequence'; // 默认顺序: sequence, single, random_list, random_all

// 2. 修改 initControls 函数，添加模式按钮和弹窗事件
function initControls() {
    // ... (保留之前的 btn-play, progress 等逻辑) ...

    // --- 新增：模式弹窗逻辑 ---
    const modeModal = document.getElementById('mode-modal');
    const modeBtn = document.getElementById('btn-mode');
    const modeOverlay = document.getElementById('mode-overlay');
    const modeClose = document.getElementById('mode-close');

    // 打开弹窗
    modeBtn.onclick = (e) => {
        e.stopPropagation();
        modeModal.classList.add('active');
    };

    // 关闭弹窗 (点击遮罩或取消按钮)
    const closeModal = () => modeModal.classList.remove('active');
    modeOverlay.onclick = closeModal;
    modeClose.onclick = closeModal;

    // 模式选择逻辑
    document.querySelectorAll('.mode-item').forEach(item => {
        item.onclick = () => {
            playMode = item.dataset.mode;
            
            // 更新 UI 选中态
            document.querySelectorAll('.mode-item').forEach(el => el.classList.remove('active'));
            item.classList.add('active');
            
            // 更新按钮图标
            updateModeIcon();
            
            // 关闭弹窗
            closeModal();

            // 如果选择了"所有随机"，立即更新当前播放列表上下文
            if (playMode === 'random_all') {
                switchToAllSongsContext();
            }
        };
    });

    // --- 修改：上一首/下一首 逻辑 ---
    // (请用下面的代码替换原来的 prevFunc 和 nextFunc 定义)
    
    const nextFunc = (e) => { 
        if(e) e.stopPropagation();
        handleTrackChange('next');
    };

    const prevFunc = (e) => { 
        if(e) e.stopPropagation(); 
        handleTrackChange('prev');
    };
    
    // 绑定按钮
    document.getElementById('btn-prev-mini').onclick = prevFunc;
    document.getElementById('btn-next-mini').onclick = nextFunc;
    document.getElementById('btn-prev-full').onclick = prevFunc;
    document.getElementById('btn-next-full').onclick = nextFunc;

    // 绑定自动播放结束
    audio.addEventListener('ended', () => {
        if (playMode === 'single') {
            audio.currentTime = 0;
            audio.play();
        } else {
            handleTrackChange('next', true); // true 表示这是自动跳转
        }
    });

    // ... (保留其他的事件绑定) ...
}

// 3. 新增：核心切歌逻辑控制
function handleTrackChange(direction, isAuto = false) {
    let nextIndex = currentIndex;
    const len = currentPlaylist.length;

    if (playMode === 'random_list' || playMode === 'random_all') {
        // 随机模式：随机取一个非当前的索引
        if (len > 1) {
            do {
                nextIndex = Math.floor(Math.random() * len);
            } while (nextIndex === currentIndex);
        }
    } else {
        // 顺序模式 或 单曲循环模式(手动切歌时视为顺序)
        if (direction === 'next') {
            nextIndex = (currentIndex + 1) % len;
        } else {
            nextIndex = (currentIndex - 1 + len) % len;
        }
    }

    playSong(nextIndex);
}

// 4. 新增：更新按钮图标
function updateModeIcon() {
    const iconMap = {
        'sequence': 'repeat',
        'single': 'repeat_one',
        'random_list': 'shuffle_on', // 或者 shuffle
        'random_all': 'shuffle'      // 视觉上可以用不同图标区分
    };
    const btnSpan = document.querySelector('#btn-mode span');
    btnSpan.innerText = iconMap[playMode];
    
    // 如果是所有随机，图标给个高亮颜色提示
    if(playMode === 'random_all') {
        btnSpan.style.color = 'var(--primary)';
    } else {
        btnSpan.style.color = ''; // 恢复默认
    }
}

// 5. 新增：切换到"所有歌曲"上下文
function switchToAllSongsContext() {
    // 如果当前已经在播放所有歌曲列表，就不需要重置
    // 这里我们简单粗暴处理：直接把 currentPlaylist 换成 allSongs
    // 但要保持当前正在播放的歌曲不错位
    
    const currentSong = currentPlaylist[currentIndex];
    
    // 切换播放列表引用
    currentPlaylist = allSongs;
    
    // 在大列表中找到当前歌曲的新索引，防止切歌错乱
    // 注意：如果有重复歌曲名，这里可能会有问题，最好对比 file 路径
    const newIndex = allSongs.findIndex(s => s.file === currentSong.file);
    if (newIndex !== -1) {
        currentIndex = newIndex;
    }
    
    // 更新 UI 列表显示
    document.getElementById('playlist-title').innerText = "所有歌曲 (随机播放)";
    renderSongList(currentPlaylist);
    
    // 清除侧边栏选中态
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
}

init();